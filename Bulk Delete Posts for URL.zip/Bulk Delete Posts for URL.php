<?php
/*
Plugin Name: Bulk Post Delete For URL
Plugin URI: https://digitablesolutions.com
Description: Elimina posts masivamente a partir de URLS (Util limpiar posts sin trafico en GSC y mejorar SEO)
Version: 1.0
Author: FJ | Digitable Solutions
Author URI: https://fj.mk
*/

// Adicionar ação para registrar a função do plugin
add_action('admin_menu', 'delete_posts_from_urls_menu');

// Função para adicionar página de configurações do plugin no painel do WordPress
function delete_posts_from_urls_menu() {
    add_options_page('Eliminar posts a partir de URLs', 'Eliminar posts a partir de URLs', 'manage_options', 'delete-posts-from-urls', 'delete_posts_from_urls_page');
}

// Función para la página de configuración del complemento
function delete_posts_from_urls_page() {
    ?>
    <div class="wrap">
        <h2>Eliminar posts a partir de URLs</h2>
        <form method="post" action="">
            <label for="urls">Añade las URLs  de los posts que deseas eliminar (Una URL por linea):</label><br>
            <textarea id="urls" name="urls" rows="5" cols="50"></textarea><br><br>
            <input type="submit" name="delete_posts" class="button button-primary" value="Eliminar">
        </form>
        <?php
        // Procesar el envío de publicaciones a la papelera
        if (isset($_POST['delete_posts'])) {
            $urls = isset($_POST['urls']) ? sanitize_textarea_field($_POST['urls']) : '';
            if (!empty($urls)) {
                $urls_array = explode("\n", $urls);
                delete_posts_from_urls_batch($urls_array);
            } else {
                echo "Ingrese las URL de las publicaciones que desea eliminar.";
            }
        }
        ?>
    </div>
    <?php
}

// Función para enviar publicaciones a la papelera mediante slugs de URL en lotes
function delete_posts_from_urls_batch($urls_array) {
    // Configuración de tiempo y lote
    $batch_size = 10; // Tamaño de lote
    $interval = 5; // Intervalo de tiempo entre los lotes en segundos

    // Dividir URLs en lotes
    $url_batches = array_chunk($urls_array, $batch_size);

    // Procesar cada lote con un intervalo de tiempo
    foreach ($url_batches as $batch) {
        foreach ($batch as $url) {
            $url_parts = parse_url(trim($url));
            $path_parts = explode('/', trim($url_parts['path'], '/'));
            $slug = end($path_parts);
            $post = get_page_by_path($slug, OBJECT, 'post');
            if ($post) {
                wp_trash_post($post->ID); // Envia a postagem para a lixeira
                echo "posts con slug $slug fue movida a la papelera con exito<br>";
            } else {
                echo "Posts con slug $slug no fue encontrada<br>";
            }
        }
        // Esperar intervalo de tiempo entre los lotes
        sleep($interval);
    }
}
?>